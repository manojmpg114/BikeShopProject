package bikeshop;

import java.io.Serializable;

/**
 * Represents a bike product.
 * @author Geoffrey Cohen
 * @author Jason DeValerio
 * @author Manoj George
 */
public class Bike extends Product implements Serializable {
	

	private static final long serialVersionUID = -8633684893035284528L;
	private int number;
	private String make, model, type, gender;
	private double price;
	
	/**
	 * Constructor.
	 * @param number
	 * @param make
	 * @param model
	 * @param type
	 * @param gender
	 * @param price
	 */
	public Bike(int number, String make, String model, String type, String gender, double price)
	{
		this.setNumber(number);;
		this.setMake(make);;
		this.setModel(model);;
		this.setType(type);
		this.setGender(gender);
		this.setPrice(price);
	}

	
	/**
	 * Gets bike number.
	 * @return bike number
	 */
	public int getNumber() {
		return number;
	}


	/**
	 * Sets bike number.
	 * @param number
	 */
	public void setNumber(int number) {
		this.number = number;
	}

	/**
	 * Gets bike make.
	 * @return bike make
	 */
	public String getMake() {
		return make;
	}

	/**
	 * Sets bike make.
	 * @param make
	 */
	public void setMake(String make) {
		this.make = make;
	}

	/**
	 * Gets bike model.
	 * @return bike model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * Sets bike model.
	 * @param model
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * Gets bike type.
	 * @return bike type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Sets bike type.
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Gets bike gender.
	 * @return bike gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * Sets bike gender.
	 * @param gender
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * Gets bike price.
	 * @return price
	 */
	public double getPrice() {
		return price;
	}
	
	/**
	 * Sets bike price.
	 * @param price
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	
	/**
	 * Overrides toString for this class.
	 */
	public String toString() {
		return this.model;
	}
}




