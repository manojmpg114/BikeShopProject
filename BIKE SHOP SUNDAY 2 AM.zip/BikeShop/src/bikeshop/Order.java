package bikeshop;

import java.io.*;
import java.util.ArrayList;
import java.util.Random;

/**
 * This class represents an Order and is composed from the Product class and extends ArrayList.
 * @author Geoffrey Cohen
 * @author Jason DeValerio
 * @author Manoj George
 */
public class Order extends ArrayList<Product> implements Serializable {
	
	private static final long serialVersionUID = -2134763355694794603L;
	private String FILE_NAME = "src/bikeshop/serialize.ser";
	private Rental rental;
	private Customer customer;
	
	/**
	 * Default constructor, no parameters.
	 */
	public Order()
	{
		
	}
	
	/**
	 * Sets the customer.
	 * @param c
	 */
	public void setCustomer(Customer c) {
		customer = c;
	}
	
	/**
	 * Gets the customer.
	 * @return customer
	 */
	public Customer getCustomer() {
		return customer;
	}
	
	/**
	 * Gets the rental.
	 * @return rental
	 */
	public Rental getRental() {
		return rental;
	}

	/**
	 * Sets the rental.
	 * @param rental
	 */
	public void setRental(Rental rental) {
		this.rental = rental;
	}
	
	/**
	 * Calculates total cost of order.
	 * @return cost
	 */
	private double calcCost() {
		double cost = 0;
		
		for(int i=0;i<this.size()-1;i++) {
			cost += this.get(i).getPrice();
		}
		
		return cost;
	}
	
	//Prints receipt That includes customer name, address, phone number, 
	//a listing of each product and deposit amount, plus a total rental amount, and a projected rental duration
	
	/**
	 * Converts order details to String for receipt.
	 * @return receipt String
	 */
	public String getReceipt() {
		Random rand = new Random();
		int ordNum = rand.nextInt();
		
		return "Order number: " + ordNum + "\n"
				+ "Customer name: " + customer.getFirstName() + " " + customer.getLastName() + "\n"
				+ customer.getAddress() + "\n"
				+ customer.getPhone() + "\n"
				+ this.toString() + "\n"
				+ "Cost:" + "$" + calcCost() + "\n"
				+ rental;

	}
	
	/**
	 * Serializes the Order object to a file.
	 */
	public void serialize()
	{

		try {
			FileOutputStream fileOut = new FileOutputStream(FILE_NAME);
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(this);
			out.close();
			fileOut.close();
			System.out.println("Product Stored in " + FILE_NAME);
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * Deserializes the Order from a file.
	 * @return the deserialized Order
	 */
	public Order deserialize()
	{
		Order hold = null;
		try{
			FileInputStream fileIn = new FileInputStream(FILE_NAME);
			ObjectInputStream objectIn = new ObjectInputStream(fileIn);
			hold = (Order)objectIn.readObject();
			objectIn.close();
			fileIn.close();
		}
		catch(IOException e){
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		return hold;
	}
}


