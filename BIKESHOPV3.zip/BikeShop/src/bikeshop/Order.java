package bikeshop;

import java.io.*;
import java.util.ArrayList;
import java.util.Random;

/**
 * This class is composed from the Product class and extends ArrayList.
 * @author Geoff
 *
 */
public class Order extends ArrayList<Product> implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2134763355694794603L;

	private String FILE_NAME = "src/bikeshop/serialize.ser";
	private Rental rental;
	private Customer customer;
	
	/**
	 * Default constructor, no parameters.
	 */
	public Order()
	{
		
	}
	
	public void setCustomer(Customer c) {
		customer = c;
	}
	
	public Customer getCustomer() {
		return customer;
	}
	
	public Rental getRental() {
		return rental;
	}

	public void setRental(Rental rental) {
		this.rental = rental;
	}
	
	private double calcCost() {
		double cost = 0;
		
		for(int i=0;i<this.size()-1;i++) {
			cost += this.get(i).getPrice();
		}
		
		return cost;
	}
	
	//Prints receipt That includes customer name, address, phone number, 
	//a listing of each product and deposit amount, plus a total rental amount, and a projected rental duration
	
	public String getReceipt() {
		Random rand = new Random();
		int ordNum = rand.nextInt();
		
		return "Order number: " + ordNum + "\n"
				+ "Customer name: " + customer.getFirstName() + " " + customer.getLastName() + "\n"
				+ customer.getAddress() + "\n"
				+ customer.getPhone() + "\n"
				+ this.toString() + "\n"
				+ "Cost:" + "$" + calcCost() + "\n"
				+ rental;

	}
	
	public void serialize()
	{

		try {
			FileOutputStream fileOut = new FileOutputStream(FILE_NAME);
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(this);
			out.close();
			fileOut.close();
			System.out.println("Product Stored in " + FILE_NAME);
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	
	public Object deserialize()
	{
		Order hold = null;
		try{
			FileInputStream fileIn = new FileInputStream(FILE_NAME);
			ObjectInputStream objectIn = new ObjectInputStream(fileIn);
			hold = (Order)objectIn.readObject();
			objectIn.close();
			fileIn.close();
		}
		catch(IOException e){
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return hold;
	}


}


