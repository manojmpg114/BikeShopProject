package bikeshop;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.stream.Collectors;

import javax.swing.*;

/**
 * The GUI class for the application. This represents an employee's interaction with the internal system. 
 * @author Geoffrey Cohen
 *
 */
public class ShopGUI extends JFrame  {

	
	private static final long serialVersionUID = 1956870984781197012L;
	
	private ArrayList<Product> inventory;
	private int empNum = 0;
	Order order = new Order();
	
	/**
	 * Constructor.
	 * @param xloc
	 * @param yloc
	 * @param xsize
	 * @param ysize
	 * @param closeActivity
	 * @param inventory
	 */
	public ShopGUI(int xloc, int yloc, int xsize, int ysize, int closeActivity, ArrayList<Product> inventory) {
		this.setMinimumSize(new Dimension(1200, 120));
		this.setLocation(xloc, yloc);
		this.setSize(xsize, ysize);
		this.setDefaultCloseOperation(closeActivity);
		this.inventory = inventory;
		this.setTitle("Bike Shop Kiosk");
		
		// get customer info
		Customer customer = new Customer();
		customer.setFirstName(JOptionPane.showInputDialog("Enter Customer First Name:"));
		customer.setLastName(JOptionPane.showInputDialog("Enter Customer Last Name:"));		
		customer.setAddress(JOptionPane.showInputDialog("Enter Customer Address:"));
		customer.setEmail(JOptionPane.showInputDialog("Enter Customer email:"));
		customer.setPhone(JOptionPane.showInputDialog("Enter Customer Phone:"));
		
		order.setCustomer(customer);

		//get employee number
		empNum = Integer.parseInt(JOptionPane.showInputDialog("Enter Employee Number:"));
		
		buildAndAdd();
		
		this.pack();
		this.setVisible(true);
	}
	
	/**
	 * Builds and adds components to the frame.
	 */
	private void buildAndAdd() {
		JPanel backPanel = new JPanel();
		backPanel.setLayout(new BorderLayout(10,10));
		JPanel north = new JPanel(), south = new JPanel(), east = new JPanel(), west = new JPanel(), center = new JPanel();
		west.setLayout(new GridLayout(0, 1));
		north.setLayout(new GridLayout(0, 1));
		center.setLayout(new GridLayout(0, 1));
		east.setLayout(new GridLayout(0, 1));
		
		//For displaying order/receipt. must be JTextArea for multiple lines
		JTextArea orderArea = new JTextArea("Order Display Area");
		
		north.add(new JLabel("Employee Number: " + empNum));
		north.add(new JLabel("Customer Being Served: " + order.getCustomer().getFirstName() + " " + order.getCustomer().getLastName()));
		
		backPanel.add(north, BorderLayout.NORTH);
		
		//For selecting items
		west.add(new JLabel("Item Selection"));
		ArrayList<Product> bikes = (ArrayList<Product>) inventory.parallelStream()
																 .filter(p -> p instanceof Bike)
																 .collect(Collectors.toCollection(ArrayList::new));
		
		ArrayList<Product> accessories = (ArrayList<Product>) inventory.parallelStream()
																 .filter(p -> p instanceof Accessory)
																 .collect(Collectors.toCollection(ArrayList::new));
		
		JPanel dropdowns = new JPanel();
		JComboBox<Bike> bikeDropdown = new JComboBox<Bike>();
		JComboBox<Accessory> accessoryDropdown = new JComboBox<Accessory>();

		for(int i=0;i<bikes.size();i++) {
			bikeDropdown.addItem((Bike) bikes.get(i));
			}
		
		for(int i=0;i<accessories.size();i++) {
			accessoryDropdown.addItem((Accessory) accessories.get(i));
			}
		
		dropdowns.add(bikeDropdown);
		dropdowns.add(accessoryDropdown);
		
		west.add(dropdowns);
		
		JButton addBikeToOrder = new JButton("Add Bike");
		addBikeToOrder.addActionListener(e -> {order.add((Product) bikeDropdown.getSelectedItem());
												JOptionPane.showMessageDialog(backPanel, bikeDropdown.getSelectedItem() + " added to order");
												orderArea.setText(order.getReceipt());
												backPanel.getTopLevelAncestor().revalidate();
												((ShopGUI) backPanel.getTopLevelAncestor()).pack();});
		
		JButton addAccToOrder = new JButton("Add Accessory");
		addAccToOrder.addActionListener(e -> {order.add((Product) accessoryDropdown.getSelectedItem());
												JOptionPane.showMessageDialog(backPanel, accessoryDropdown.getSelectedItem() + " added to order");
												orderArea.setText(order.getReceipt());
												backPanel.getTopLevelAncestor().revalidate();
												((ShopGUI) backPanel.getTopLevelAncestor()).pack();});
		
		JButton orderNewBikes = new JButton("Order New Bikes");
		ArrayList<Bike> orderedBikes = orderBikes();
		orderNewBikes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(backPanel, "New bikes ordered: \n" + orderedBikes);
				while(!orderedBikes.isEmpty()) {
					bikeDropdown.addItem(orderedBikes.remove(0));
				}
				backPanel.getTopLevelAncestor().revalidate();
				((ShopGUI) backPanel.getTopLevelAncestor()).pack();
			}
		});

		west.add(addBikeToOrder);
		west.add(addAccToOrder);
		west.add(orderNewBikes);
		
		backPanel.add(west, BorderLayout.WEST);	
		
		center.add(new JLabel("Current Order"));
		
		JPanel OrderDisplay = new JPanel();
		OrderDisplay.setLayout(new GridLayout(0, 2, 10, 5));
		OrderDisplay.setBackground(Color.WHITE);
		
		OrderDisplay.add(orderArea);
		
		center.add(OrderDisplay);
		
		JButton serialize = new JButton("Serialize/Deserialize Order");
		serialize.addActionListener(e -> {  order.serialize();
											order.deserialize();
											backPanel.getTopLevelAncestor().revalidate();
											((ShopGUI) backPanel.getTopLevelAncestor()).pack();});
		
		center.add(serialize);
		
		backPanel.add(center, BorderLayout.CENTER);
		
		Rental rental = new Rental();		
		
		JButton addBikeToRental = new JButton("Add Bike to Rental");

		addBikeToRental.addActionListener(e -> { rental.addProduct((Bike) bikeDropdown.getSelectedItem());
												JOptionPane.showMessageDialog(backPanel, bikeDropdown.getSelectedItem() + " added to rental");
												backPanel.getTopLevelAncestor().revalidate();
												((ShopGUI) backPanel.getTopLevelAncestor()).pack();});
		JButton rent = new JButton("Rent");
		
		rent.addActionListener(e -> {rental.setRentalDuration(Integer.parseInt(JOptionPane.showInputDialog("Enter rental duration in days")));
										rental.calcRentalTotal();
										rental.setRentalDeposit(rental.getRentalTotal()/5);
										rental.setDailyCharge((rental.getRentalTotal()-rental.getRentalDeposit())/rental.getRentalDuration());
										JOptionPane.showMessageDialog(backPanel, "Rent success!");
										order.setRental(rental);
										orderArea.setText(order.getReceipt());
										backPanel.getTopLevelAncestor().revalidate();
										((ShopGUI) backPanel.getTopLevelAncestor()).pack();});		
		
		//for renting
		east.add(new JLabel("Rental"));
		east.add(addBikeToRental);
		east.add(rent);
		
		backPanel.add(east, BorderLayout.EAST);
		
		//for returning rentals
		south.add(new JLabel("Rental Returns"));
		
		JButton returnRental = new JButton("Return Rental");
		returnRental.addActionListener(e -> {if(JOptionPane.showConfirmDialog(backPanel, "Is the return late?") == JOptionPane.YES_OPTION) {
				JOptionPane.showMessageDialog(backPanel, "Late fee added! $10");
		}});
		
		south.add(returnRental);
		
		backPanel.add(south, BorderLayout.SOUTH);

		this.add(backPanel);
	}
	
	/**
	 * Orders a new list of bikes.
	 * @return list of bikes
	 */
	private ArrayList<Bike> orderBikes() {
		ArrayList<Bike> bikes = new ArrayList<Bike>();
		
		bikes.add(new Bike(1242, "Super Cool", "Extreme Bike", "BMX", "Men's", 150.00));
		bikes.add(new Bike(3151, "Super Cute", "Princess Bike", "Children's", "Women's", 50.00));
		bikes.add(new Bike(3151, "Super Climber", "UltraSummit", "Mountain", "Men's/Women's", 300.00));
		
		return bikes;
	}
}
