package bikeshop;

import java.io.Serializable;

/**
 * Represents a customer.
 * @author Geoffrey Cohen
 * @author Jason DeValerio
 * @author Manoj George
 */
public class Customer extends Person  implements Serializable  {

	private static final long serialVersionUID = -2566147161348635405L;
	String email;
	String phone;
	String address;
	
	/**
	 * Default constructor.
	 */
	public Customer()
	{
		
	}
	
	/**
	 * Overloaded constructor.
	 * @param email
	 * @param address
	 * @param phone
	 */
	public Customer(String email, String address, String phone)
	{
		this.email = email;
		this.address = address;
		this.phone = phone;
	}
	
	/**
	 * Get customer email.
	 * @return email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Set customer email.
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Get customer phone.
	 * @return phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * Set customer phone.
	 * @param phone
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * Get customer address.
	 * @return address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * Set customer address.
	 * @param address
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
