package bikeshop;

import java.io.Serializable;

/**
 * This class allows instantiation of any miscellaneous accessory
 * the bike shop might sell. It holds the item's name (what it is) and price.
 * @author Geoffrey Cohen
 * @author Jason DeValerio
 * @author Manoj George
 *
 */
public class Accessory extends Product implements Serializable {

	private static final long serialVersionUID = 6944812276441458104L;
	private double price;
	private String itemName;
	
	/**
	 * Constructor.
	 * @param price
	 * @param itemName
	 */
	public Accessory(double price, String itemName)
	{
		this.setPrice(price);
		this.setItemName(itemName);
	}
	
	/**
	 * Gets price.
	 */
	public double getPrice() {
		return price;
	}
	
	/**
	 * Sets price.
	 * @param price
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	
	/**
	 * Gets item name.
	 * @return item name
	 */
	public String getItemName() {
		return itemName;
	}
	
	/**
	 * Sets item name.
	 * @param itemName
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	
	/**
	 * Overrides toString for this class.
	 */
	public String toString() {
		return this.itemName;
	}
}


