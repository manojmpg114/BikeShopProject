package bikeshop;

import java.time.LocalDate;

/**
 * Thrown if order is not found.
 * @author Manoj George
 */
public class OrderNotFoundException extends Exception{
	
	
	private static final long serialVersionUID = -6396734929352925637L;
	String file;
	static LocalDate time;
	
	/**
	 * Constructor.
	 * @param file
	 */
	public OrderNotFoundException(String file)
	{
		super(file + " doesn't exist at " +  LocalDate.now());
		this.file = file;
	}
}
