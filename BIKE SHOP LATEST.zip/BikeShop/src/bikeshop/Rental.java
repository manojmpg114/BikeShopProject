package bikeshop;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Represents a rental.
 * @author Geoffrey Cohen
 * @author Jason DeValerio
 * @author Manoj George
 */
public class Rental  implements Serializable  {
	
	private static final long serialVersionUID = 5293922153978331850L;
	private double rentalDeposit, dailyCharge, rentalTotal;
	private int rentalDuration;

	private ArrayList<Product> productList;
	
	//**Default Constructor
	public Rental()
	{
		productList = new ArrayList<Product>();
	}
	
	public Rental(Bike bike) {
		
	}
	
	// MOVED PRINTRECEIPT TO ORDER
	
	//Setters and Getters
	public double getRentalDeposit() {
		return rentalDeposit;
	}

	public void setRentalDeposit(double rentaDeposit) {
		this.rentalDeposit = rentaDeposit;
	}

	public double getRentalTotal() {
		return rentalTotal;
	}


	public void calcRentalTotal() {
		for(int i=0;i<productList.size()-1;i++) {
			rentalTotal += productList.get(i).getPrice() / 10;
		}
	}


	public double getDailyCharge() {
		return dailyCharge;
	}

	public void setDailyCharge(double dailyCharge) {
		this.dailyCharge = dailyCharge;
	}

	public ArrayList<Product> getProductList() {
		return productList;
	}

	public void setProductList(ArrayList<Product> productList) {
		this.productList = productList;
	}

	public void addProduct(Product product)
	{
		productList.add(product);
	}
	
	public int getRentalDuration() {
		return rentalDuration;
	}

	public void setRentalDuration(int rentalDuration) {
		this.rentalDuration = rentalDuration;
	}
	
	public String toString() {
		return "Rental info:"
				+ "\nDuration: " + rentalDuration + " days"
				+ "\nDeposit: $" + rentalDeposit 
				+ "\nTotal cost: $" + rentalTotal
				+ "\nDaily charge: $" + dailyCharge
				+ "\nBikes rented: " + productList;
	}
}
