package bikeshop;

/**
 * Represents an employee.
 * @author Manoj George
 */
public class Employee extends Person {
	
	Boss boss;
	int id;
	
	/**
	 * Default constructor.
	 */
	public Employee()
	{
		
	}
	
	/**
	 * Overloaded constructor.
	 * @param fn first name
	 * @param ln last name
	 */
	public Employee(String fn, String ln) {
		super(fn, ln);
	}
	
	/**
	 * Overloaded constructor with id.
	 * @param fn first name
	 * @param ln last name
	 * @param id identification number
	 */
	public Employee(String fn, String ln, int id)
	{
		super(fn,ln);
		this.id = id;
	}
	
	/**
	 * Gets employee id.
	 * @return id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Sets employee id.
	 * @param id
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	
	/**
	 * inner class of the bike shops employees, the boss.
	 * @author Manoj George
	 */
	private class Boss
	{
		final int ID = 666;
		String lastName;
		
		/**
		 * Constructor.
		 * @param lastName
		 */
		public Boss(String lastName)
		{
			this.lastName = lastName;
		}
		
		/**
		 * Gets boss name.
		 * @return name
		 */
		public String getName()
		{
			String r = ("Mr." + this.lastName);
			return r;
		}
		
		/**
		 * Gets boss id.
		 * @return id
		 */
		public int getID()
		{
			return this.ID;
		}
		
		/**
		 * Employee request.
		 */
		public void employeeRequest()
		{
			System.out.println("Whats the issue? I'm a very busy individual");
		}
	}
	
	/**
	 * Gets boss.
	 */
	public void getBoss()
	{
		boss = new Boss("George");
		boss.employeeRequest();
	}
}
