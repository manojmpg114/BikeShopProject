package bikeshop;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;

/**
 * Driver class.
 * @author Geoffrey Cohen
 * @author Jason DeValerio
 * @author Manoj George
 */
public class Driver {
	static List<Product> inventory = new ArrayList<Product>();


	/**
	 * Main method.
	 * @param args
	 */
	public static void main(String[] args) {
		
		generateInventory(inventory);
		ShopGUI gui = new ShopGUI(0, 0, 1200, 120, JFrame.EXIT_ON_CLOSE, inventory);
	}

	/**
	 * Generates shop inventory.
	 * @param list
	 */
	public static void generateInventory(List<Product> list) {
		list.add(new Accessory(19.99, "Adult Helmet"));
		list.add(new Accessory(9.99, "Adult Pads"));
		list.add(new Accessory(7.99, "Child Pads"));
		list.add(new Accessory(10.99, "Adult Gloves"));
		list.add(new Accessory(8.99, "Child Gloves"));
		list.add(new Bike(1, "Steel", "ALAN", "BMX", "M", 59.37));
		list.add(new Bike(2, "Carbon Fiber", "Pinarello", "RoadCycle", "M", 230.99));
		list.add(new Bike(3, "Plastic", "ToysRUs", "Tricycle", "F", 13));
		list.add(new Bike(4, "Steel", "DicksSG", "Tandum", "MF", 49.99));
	}
}






