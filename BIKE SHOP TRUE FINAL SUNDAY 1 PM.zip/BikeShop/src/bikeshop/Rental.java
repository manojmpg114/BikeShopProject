package bikeshop;

import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;

/**
 * Represents a rental.
 * @author Geoffrey Cohen
 * @author Jason DeValerio
 * @author Manoj George
 */
public class Rental  implements Serializable  {
	
	private static final long serialVersionUID = 5293922153978331850L;
	private double rentalDeposit, dailyCharge, rentalTotal;
	private int rentalDuration;

	private List<Product> productList;
	
	/**
	 * Default constructor.
	 */
	public Rental()
	{
		productList = new ArrayList<Product>();
	}
	
	/**
	 * Overloaded constructor for passing Bike.
	 * @param bike
	 */
	public Rental(Bike bike) {
		
	}
	
	/**
	 * Gets rental deposit.
	 * @return deposit
	 */
	public double getRentalDeposit() {
		return rentalDeposit;
	}

	/**
	 * Sets rental deposit.
	 * @param rentaDeposit
	 */
	public void setRentalDeposit(double rentaDeposit) {
		this.rentalDeposit = rentaDeposit;
	}

	/**
	 * Gets rental total.
	 * @return total
	 */
	public double getRentalTotal() {
		return rentalTotal;
	}

	/**
	 * Calculates the rental total.
	 */
	public void calcRentalTotal() {
		for(int i=0;i<productList.size()-1;i++) {
			rentalTotal += productList.get(i).getPrice() / 10;
		}
	}

	/**
	 * Gets daily charge.
	 * @return daily charge
	 */
	public double getDailyCharge() {
		return dailyCharge;
	}

	/**
	 * Sets daily charge.
	 * @param dailyCharge
	 */
	public void setDailyCharge(double dailyCharge) {
		this.dailyCharge = dailyCharge;
	}

	/**
	 * Gets product list.
	 * @return product list
	 */
	public List<Product> getProductList() {
		return productList;
	}

	/**
	 * Sets product list.
	 * @param productList
	 */
	public void setProductList(ArrayList<Product> productList) {
		this.productList = productList;
	}

	/**
	 * Adds product to product list.
	 * @param product
	 */
	public void addProduct(Product product)
	{
		productList.add(product);
	}
	
	/**
	 * Gets rental duration.
	 * @return
	 */
	public int getRentalDuration() {
		return rentalDuration;
	}

	/**
	 * Sets rental duration.
	 * @param rentalDuration
	 */
	public void setRentalDuration(int rentalDuration) {
		this.rentalDuration = rentalDuration;
	}
	
	/**
	 * Creates String representation of class.
	 */
	public String toString() {
		return "Rental info:"
				+ "\nDuration: " + rentalDuration + " days"
				+ "\nDeposit: $" + rentalDeposit 
				+ "\nTotal cost: $" + rentalTotal
				+ "\nDaily charge: $" + dailyCharge
				+ "\nBikes rented: " + productList;
	}
}
