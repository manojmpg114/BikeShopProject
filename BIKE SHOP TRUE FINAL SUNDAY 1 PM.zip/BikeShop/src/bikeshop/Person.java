package bikeshop;
/**
 * Represents a person.
 * @author Manoj George
 */
public class Person {

	String firstName;
	String lastName;
	
	/**
	 * Default constructor.
	 */
	public Person()
	{
		
	}
	
	/**
	 * Overloaded constructor.
	 * @param fn first name
	 * @param ln last name
	 */
	public Person(String fn, String ln)
	{
		this.firstName = fn;
		this.lastName = ln;
	}
	
	/**
	 * Gets first name.
	 * @return first name
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets first name.
	 * @param firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Gets last name.
	 * @return last name
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Sets last name.
	 * @param lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
}
